package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String getHash(@RequestParam(value = "name", defaultValue = "World") String name) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(name.getBytes());

            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedHash) {
                hexString.append(String.format("%02x", b));
            }

            return "<h1>Name: " + name + "</h1><p>Hash of data string: " + hexString.toString() + "</p>";
        } catch (NoSuchAlgorithmException e) {
            return "Error generating hash";
        }
    }
}
